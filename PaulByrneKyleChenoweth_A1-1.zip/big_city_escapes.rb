require 'artii'
require 'colorize'

class EscapeRoom

    attr_reader(:name, :items)

    def initialize(name)
        @name = name
        @items = []
    end

    def add_item(item)
        @items << item
    end

    def is_in_items?(item)
        # item is a string

        @items.each do |hash|
            if hash[:item] == item
                return true
            end
        end
        return false
    end

    def remove_item(item)
        # Removes 'item' from @items if 'item' is in @items
        @items.each_index do |index|
            if @items[index][:item] == item
                @items.delete_at(index)
            end
        end
    end

    def to_s()
        return "#{@name} has these items: #{@items}"
    end
end


class Player

    attr_reader(:name, :health, :score)
    def initialize(name)
        @name = name
        @inventory = []
        @health = 100
        @score = 0
    end

    def add_item(item)
        @inventory << item
    end

    def change_health(increment)

        if @health + increment <= 0
            return "Game Over, your journey has come to an end!"
        end
        @health += increment
        return nil
    end

    def update_score(increment)
        @score += increment
    end

    def is_in_inventory?(item)
        # item is a string
        @inventory.each do |inventory_item|
            if inventory_item == item
                return true
            end
        end
        return false
    end

    def to_s()
        return "#{@name} has health: #{@health}, score: #{@score}, and these items: #{@inventory}"
    end
end


class TheBoat < EscapeRoom

    def print_north_direction
        if self.is_in_items?("Bird Seed")
            bird_string = "a bag of bird seed and "
        else 
            bird_string = ""
        end

        puts "You are facing north, you see #{bird_string}a radio"
        puts "\n1. Look East\n2. Look West\n3. Look South\n4. Try calling for help with Radio"

        if self.is_in_items?("Bird Seed")
            puts "5. Pick up bird seed (may be useful later)"
        end
    end

    def north_choice(choice, player)

        if choice == 1 
            puts "Changing direction to the East"
            return "E"

        elsif choice == 2
            puts "Changing direction to the West"
            return "W"

        elsif choice == 3
            puts "Changing direction to the South"
            return "S"

        elsif choice == 4
            puts "You grabbed the radio and try a mayday call to get help, unlucky pal, flat batteries!!!"

        elsif choice == 5 && self.is_in_items?("Bird Seed")
            puts "Picking up bird seed"
            # Move bird seed from boat to player
            self.remove_item("Bird Seed")
            player.add_item("Bird Seed")

        else 
            puts "This is an invalid response"
        end

        return nil
    end

    def print_east_direction

        if self.is_in_items?("Fire Axe")
            fire_string = "and a fire axe"
        else 
            fire_string = ""
        end

        puts "You are facing East, you see a beautiful view of the Empire State building #{fire_string}"
        puts "\n1. Look North\n2. Look West\n3. Look South\n4. Try to swim to the shore"

        if self.is_in_items?("Fire Axe")
            puts "5. Pick up Fire Axe"
        end

    end

    def east_choice(choice, player)

        if choice == 1 
            puts "Changing direction to the North"
            return "N"

        elsif choice == 2
            puts "Changing direction to the West"
            return "W"

        elsif choice == 3
            puts "Changing direction to the South"
            return "S"

        elsif choice == 4
            puts "You dip your toes in the water and lose them from frostbite"
            puts "You incur a health penalty of 25 hearts"
            lose = player.change_health(-25)
            if lose
                return lose
            end

        elsif choice == 5 && self.is_in_items?("Fire Axe")
            puts "Pick up Fire Axe"
            # Move fire axe from boat to player
            self.remove_item("Fire Axe")
            player.add_item("Fire Axe")

        else 
            puts "This is an invalid response"
        end

        return nil
    end

    def print_south_direction
        puts "You are facing South. Alas! You have spotted a mysterious crate"
        puts "\n1. Look North\n2. Look West\n3. Look East\n4. Try to open the crate"
    end

    
    def south_choice(choice, player)
        if choice == 1 
            puts "Changing direction to the North"
            return "N"
        elsif choice == 2
            puts "Changing direction to the West"
            return "W"
        elsif choice == 3
            puts "Changing direction to the East"
            return "E"
        elsif choice == 4 
            if player.is_in_inventory?("Fire Axe")

                player.update_score(150)
                puts" You have used the fire axe to bust open the crate! Inside the crate is a flare which you use to shoot in the air and behold, Captain Sully just happens to be flying by and decides to drop a rope down and tow to the the edge of the lake before your boat sinks.
                Congratulations! You have won 150 points with a total of #{player.score}. Phew, that was close! Please make your way out of Central Park and grab a cab to the airport for your next destination."

                dest_input = 0
                while dest_input != 1
                    puts "Enter 1 to board your flight and travel to the next destination"
                    print ": "
                    dest_input = gets.strip.to_i() 
                end
                puts "\n" * 20
                return "exit"
            else 
                puts "You try to open the crate with your hands but fail, you need a more powerful tool to open the crate"
            end

        else 
            puts "This is an invalid response"
        end
    end

    def print_west_direction

        if self.is_in_items?("Pizza")
            pizza_string = "next to something delicious. The crust is cooked to perfection and the thickness of the crust is not thin but not super thick either. Just right in the middle. On top of that is some incredible tomato sauce slathered with peperoni and cheese - Big New York style slice pizza."
        else 
            pizza_string = ""
        end

        puts "You are facing West. You see a life jacket lying on the floor #{pizza_string}"
        puts "\n1. Look North\n2. Look South\n3. Look East\n4. Wear Life Jacket."

        if self.is_in_items?("Pizza")
            puts "5. Eat Pizza"
        end
    end

    def west_choice(choice, player)

        if choice == 1 
            puts "Changing direction to the North"
            return "N"

        elsif choice == 2
            puts "Changing direction to the South"
            return "S"

        elsif choice == 3
            puts "Changing direction to the East"
            return "E"

        elsif choice == 4 
            puts "You are outta luck, the life jacket is as old and got holes in it"

        elsif choice == 5 && self.is_in_items?("Pizza")
            
            player.change_health(+25)
            puts "That glorious Pizza just earnt you 25 Hearts. Your current health total is: #{player.health}"
            self.remove_item("Pizza")
        else 
            puts "This is an invalid response"
        end
        return nil
    end

end


class AusOpenBox < EscapeRoom

    def print_north_direction

        if self.is_in_items?("Sports Drink")
            drink_string = "At your feet there is one unopened, cool, crisp, refreshing generic sports drink"
        else
            drink_string = ""
        end 

        puts "You are facing North. You see the center court with a few seagulls picking up the scraps left in the stands. #{drink_string}"

        puts "\n1. Look East\n2. Look West\n3. Look South"
        if self.is_in_items?("Sports Drink")
            puts "4. Drink Sports Drink"
        end
    end

    def north_choice(choice, player)
        if choice == 1 
            puts "Changing direction to the East"
            return "E"

        elsif choice == 2
            puts "Changing direction to the West"
            return "W"

        elsif choice == 3
            puts "Changing direction to the South"
            return "S"

        elsif choice == 4 && self.is_in_items?("Sports Drink")
            
            player.change_health(+25)
            puts "That effervescent sports drink just earnt you 25 Hearts. Your current health total is: #{player.health}"
            self.remove_item("Sports Drink")
        else 
            puts "This is an invalid response"
        end
        return nil
    end

    def print_east_direction
        puts "You are facing East. You spot a big red toolbox in the corner of the room along with one single brick. These items must have been left there by construction workers. "

        puts "1. Look North\n2. Look West\n3. Look South\n4. Throw brick at window\n5. Open the toolbox"
    end

    def east_choice(choice, player)

        if choice == 1 
            puts "Changing direction to the North"
            return "N"

        elsif choice == 2
            puts "Changing direction to the West"
            return "W"

        elsif choice == 3
            puts "Changing direction to the South"
            return "S"

        elsif choice == 4
            puts "When you throw the brick at the window it bounces straight back into your forehead"
            lose = player.change_health(-25)
            if lose
                return lose
            end
            puts "You've just lost yourself 25 hearts. Your total current health is: #{player.health}"

        elsif choice == 5

            if player.is_in_inventory?("Key") && self.is_in_items?("Screwdriver")
                puts "You unlock the toolbox and find a sturdy, yet capable screwdriver. You take it."
                self.remove_item("Screwdriver")
                player.add_item("Screwdriver")
            elsif player.is_in_inventory?("Key") && !self.is_in_items?("Screwdriver")
                puts "You have already taken all you can from this toolbox"
            else 
                puts "You fail to open the toolbox, it is locked tight."
            end
        else 
            puts "This is an invalid response"
        end
        return nil

    end

    def print_south_direction
        puts "You are facing South. You see the commentary desk loaded with tennis memarobilia and it has three drawers."

        puts "1. Look North\n2. Look West\n3. Look East\n4. Open the first drawer.\n5. Open the second drawer.\n6. Open the third drawer."
    end

    def south_choice(choice, player)

        if choice == 1 
            puts "Changing direction to the North"
            return "N"

        elsif choice == 2
            puts "Changing direction to the West"
            return "W"

        elsif choice == 3
            puts "Changing direction to the East"
            return "E"

        elsif choice == 4
            puts "Inside the drawer you find a note that reads: 'Hey Lleyton, got a joke for ya: \"What is the definition of endless love?...  Stevie Wonder and Ray Charles playing tennis\" Lots of love - Jim Courier'"
        
        elsif choice == 5
            if self.is_in_items?("Key")
                puts "Inside the drawer you find the golden key!"
                self.remove_item("Key")
                player.add_item("Key")
            else
                puts "You find an empty drawer"
            end
        
        elsif choice == 6

            if self.is_in_items?("Headband")
                puts "You open the draw and find Pat Cash's 1987 checkered headband and sell it on ebay for 100 bonus points"
                self.remove_item("Headband")
                player.update_score(100)
                puts "Your score is now: #{player.score}"

            else
                puts "The drawer is empty"
            end

        else 
            puts "This is an invalid response"
        end
        return nil
    end

    def print_west_direction
        puts "You are facing West. You see a vent towards the ceiling and a beam of daylight"

        puts "1. Look North\n2. Look South\n3. Look East\n4. Remove the grill"
    end

    def west_choice(choice, player)

        if choice == 1 
            puts "Changing direction to the North"
            return "N"
        elsif choice == 2
            puts "Changing direction to the South"
            return "S"
        elsif choice == 3
            puts "Changing direction to the East"
            return "E"
        elsif choice == 4 
            if player.is_in_inventory?("Screwdriver")

                player.update_score(150)
                puts "You have used the screwdriver to undo the screws holding the grill on the vent. You are temporarily blinded by the daylight and the smell of freedom greets your nose. You climb out and are now free plus earnt yourself 150 points with a total of #{player.score}. Please make your way to Melbourne airport to board your plane for your next destination"

                dest_input = 0
                while dest_input != 1
                    puts "Enter 1 to board your flight and travel to the next destination"
                    print ": "
                    dest_input = gets.strip.to_i() 
                end
                return "exit"
            else 
                puts "You try to open the vent but realised it is fastened down with screws"
            end

        else 
            puts "This is an invalid response"
        end
    end
end


class TheDungeon < EscapeRoom

    def print_north_direction

        if self.is_in_items?("Prison Slop")
            prison_string = " and on the cold floor a bowl of prison slop"
        else
            prison_string = ""
        end

        puts "You are facing North. On the wall are some rusty shackles#{prison_string}"
        puts "\n1. Look East\n2. Look South\n3. Look West"

        if self.is_in_items?("Prison Slop")
            puts "4. Eat prison slop"
        end
    end

    def north_choice(choice, player)

        if choice == 1 
            puts "Changing direction to the East"
            return "E"

        elsif choice == 2
            puts "Changing direction to the South"
            return "S"

        elsif choice == 3
            puts "Changing direction to the West"
            return "W"

        elsif choice == 4 && self.is_in_items?("Prison Slop")
            lose = player.change_health(-25)
            if lose
                return lose
            end
            puts "That ghetto prison slop has been for 50 years you fool! You just earnt yourself the devil incarnated as your new stomach bug. Your current health total is: #{player.health}"
            self.remove_item("Prison Slop")
        else 
            puts "This is an invalid response"
        end
        return nil


    end

    def print_east_direction

        if self.is_in_items?("Book")
            book_string = "and next to it an old leather bound book"
        else
            book_string = ""
        end
        puts "You are facing East. You see on the cobblestone floor a bed of hay #{book_string}."
        puts "\n1. Look North\n2. Look South\n3. Look West\n4. You seem tired, you lay down on the bed of hay"

        if self.is_in_items?("Book")
            puts "5. Pick up book"
        end
    end

    def east_choice(choice, player)

        if choice == 1 
            puts "Changing direction to the North"
            return "N"

        elsif choice == 2
            puts "Changing direction to the South"
            return "S"

        elsif choice == 3
            puts "Changing direction to the West"
            return "W"

        elsif choice == 4
            lose = player.change_health(-25)
            if lose
                return lose
            end
            puts "You lie down and prepare for a restful and peaceful sleep. BANG! You feel the teeth of a rat the size of a snowy mountain brumby gnawing at your neck! You lose 25 hearts of health. Your current health total is: #{player.health}"
        
        elsif choice == 5 && self.is_in_items?("Book")
            puts "You pick up the book and it seems like it's a part of a 'set' of books."
            self.remove_item("Book")
            player.add_item("Book")
        else 
            puts "This is an invalid response"
        end
        return nil
    end

    def print_south_direction
       
        if self.is_in_items?("Bangers and Mash")
            mash_string = "and next to it the english staple: Bangers and Mash."
        else
            mash_string = ""
        end
        puts "You are facing South. You see a large bookshelf with a set of books #{mash_string}"
        puts "\n1. Look North\n2. Look East\n3. Look West\n4. Investigate bookshelf"

        if self.is_in_items?("Bangers and Mash")
            puts "5. Eat the Bangers and Mash"
        end

    end

    def south_choice(choice, player)

        if choice == 1 
            puts "Changing direction to the North"
            return "N"

        elsif choice == 2
            puts "Changing direction to the East"
            return "E"

        elsif choice == 3
            puts "Changing direction to the West"
            return "W"

        elsif choice == 4
            if player.is_in_inventory?("Book")

                player.update_score(150)
                puts "The bookshelves shudders and Guy Fawkes appears from a cloud of dust with some spare dynamite. Guy offers to blast you out of the dungeon. You graciously accept and make your way to freedom having earnt yourself 150 points! Your total is now #{player.score}"
                dest_input = 0
                while dest_input != 1
                    puts "Enter 1 to make your way to the finish line!"
                    print ": "
                    dest_input = gets.strip.to_i()
                end
                return "exit"
            else
                puts "You investigate the bookshelf and it seems like it is missing a book in a set of books"
            end

        elsif choice == 5
            puts "You indulge yourself in the delights of the meal."
            player.change_health(25)
            puts "You gain 25 hearts of health, your health total is now: #{player.health}"
            self.remove_item("Bangers and Mash")
            
        else 
            puts "This is an invalid response"
        end
        return nil
    end

    def print_west_direction
        puts "You are facing West. You see Jack the Ripper sharpening his blades"
        puts "\n1. Look North\n2. Look East\n3. Look South\n4. Wolf whistle at Jack the Ripper"
    end

    def west_choice(choice, player)

        if choice == 1 
            puts "Changing direction to the North"
            return "N"

        elsif choice == 2
            puts "Changing direction to the East"
            return "E"

        elsif choice == 3
            puts "Changing direction to the South"
            return "S"
        
        elsif choice == 4
            puts "You let out the most antagonising wolf whistle you can muster at Jack the Ripper. His head shoots up from his blades and rushes over to slice you a couple times with his dagger"
            
            lose = player.change_health(-25)
            if lose
                return lose
            end
            puts "Good Job, you just lost yourself 25 hearts. Your total health is now: #{player.health}"

        else 
            puts "This is an invalid response"
        end
        return nil
    end
end


def boat_escape(player)
    boat = TheBoat.new("boat")

    fire_axe_hash = {
        item: "Fire Axe",
        direction: "E"
    }

    bird_seed_hash = {
        item: "Bird Seed", 
        direction: "N"
    }

    pizza_hash = {
        item: "Pizza",
        direction: "W"
    }

    boat_items = {
        fire_axe: fire_axe_hash,
        bird_seed: bird_seed_hash,
        pizza: pizza_hash
    }

    boat.add_item(boat_items[:fire_axe])
    boat.add_item(boat_items[:bird_seed])
    boat.add_item(boat_items[:pizza])

    puts "\n" * 20
    puts "Look around your sinking vessel and you will be presented with a number of options that could possibly save your life. Quick there's not much time!"

    player_direction = "N"

    game_over = false
    trapped = true
    while trapped && !game_over

        if player_direction == "N"

            boat.print_north_direction
    
            print ": "
            choice = gets().strip().to_i() 
            puts "\n" * 20
            location = boat.north_choice(choice, player)
            if location
                player_direction = location
            end

        elsif player_direction == "E"
            # Puts Description
            # List of options
            
            boat.print_east_direction
            print ": "
            choice = gets().strip().to_i() # Check input is good 
            puts "\n" * 20

            location = boat.east_choice(choice, player)
            if location == "Game Over, your journey has come to an end!"
                puts location
                game_over = true
            elsif location
                player_direction = location
            end

        elsif player_direction == "S"
            # Puts Description
            # List of options
            boat.print_south_direction
            
            print ": "
            choice = gets().strip().to_i() # Check input is good 
            puts "\n" * 20

            location = boat.south_choice(choice, player)
            if location == "exit"
                trapped = false
            elsif location
                player_direction = location
            end

        elsif player_direction == "W"
            
            boat.print_west_direction

            print ": "
            choice = gets().strip().to_i() 
            puts "\n" * 20
            
            location = boat.west_choice(choice, player)
            if location
                player_direction = location
            end
        end
    end

    if game_over
        return false
    else 
        return true
    end
end

def aus_open_escape(player)
    aus_open_commbox = AusOpenBox.new("Australian Open Commentary Box")

    sports_drink_hash = {
        item: "Sports Drink",
        direction: "N"
    }

    screwdriver_hash = {
        item: "Screwdriver",
        direction: "E"
    }

    toolbox_key_hash = {
        item: "Key",
        direction: "S"
    }

    pat_cash_hash = {
        item: "Headband",
        direction: "S"
    }

    aus_open_items = {
        sports_drink: sports_drink_hash,
        screwdriver: screwdriver_hash,
        toolbox_key: toolbox_key_hash,
        pat_cash: pat_cash_hash
    }

    aus_open_commbox.add_item(aus_open_items[:sports_drink])
    aus_open_commbox.add_item(aus_open_items[:screwdriver])
    aus_open_commbox.add_item(aus_open_items[:toolbox_key])
    aus_open_commbox.add_item(aus_open_items[:pat_cash])


    player_direction = "N"

    game_over = false
    trapped = true
    while trapped && !game_over
        if player_direction == "N"

            aus_open_commbox.print_north_direction
    
            print ": "
            choice = gets().strip().to_i()  
            puts "\n" * 20
            location = aus_open_commbox.north_choice(choice, player)
            if location
                player_direction = location
            end

        elsif player_direction == "E"
            # Puts Description
            # List of options
            
            aus_open_commbox.print_east_direction
            print ": "
            choice = gets().strip().to_i() 
            puts "\n" * 20

            location = aus_open_commbox.east_choice(choice, player)
            if location == "Game Over, your journey has come to an end!"
                puts location
                game_over = true
            elsif location
                player_direction = location
            end
        elsif player_direction == "S"
            # Puts Description
            # List of options
            aus_open_commbox.print_south_direction
            
            print ": "
            choice = gets().strip().to_i() # Check input is good 
            puts "\n" * 20

            location = aus_open_commbox.south_choice(choice, player)
            if location
                player_direction = location
            end

        elsif player_direction == "W"
            
            aus_open_commbox.print_west_direction

            print ": "
            choice = gets().strip().to_i()  
            puts "\n" * 20
            
            location = aus_open_commbox.west_choice(choice, player)
            if location == "exit"
                trapped = false
            elsif location
                player_direction = location
            end
        end
    end

    if game_over
        return false
    else 
        return true
    end

end

def london_dungeon(player)
    dungeon = TheDungeon.new("The London Dungeon")

    slop_hash = {
        item: "Prison Slop",
        direction: "N"
    }

    book = {
        item: "Book",
        direction: "E"
    }

    bangers_and_hash = {
        item: "Bangers and Mash",
        direction: "S"
    }

    dungeon_items = {
        prison_slop: slop_hash,
        book: book,
        bangers_and_mash: bangers_and_hash
    }

    dungeon.add_item(dungeon_items[:prison_slop])
    dungeon.add_item(dungeon_items[:book])
    dungeon.add_item(dungeon_items[:bangers_and_mash])

    choice = 0
    while choice != 1
        puts "You wake up. It is pitch black. It smells and feels like you are in a London dungeon"
        print ": "
        puts "1. Press 1 to find something to light up the room"
        choice = gets().strip().to_i()
    end
    puts "\n" * 20
    puts "You light up the room with an old lighter you find on the floor"
        
    player_direction = "N"

    game_over = false
    trapped = true
    while trapped && !game_over

        if player_direction == "N"

            dungeon.print_north_direction
    
            print ": "
            choice = gets().strip().to_i()
            puts "\n" * 20
            
            location = dungeon.north_choice(choice, player)
            
            if location == "Game Over, your journey has come to an end!"
                puts location
                game_over = true
            elsif location
                player_direction = location
            end

        elsif player_direction == "E"
            # Puts Description
            # List of options
            
            dungeon.print_east_direction
            print ": "
            choice = gets().strip().to_i()
            puts "\n" * 20

            location = dungeon.east_choice(choice, player)
            if location == "Game Over, your journey has come to an end!"
                puts location
                game_over = true
            elsif location
                player_direction = location
            end

        elsif player_direction == "S"
            # Puts Description
            # List of options
            dungeon.print_south_direction
            
            print ": "
            choice = gets().strip().to_i()
            puts "\n" * 20

            location = dungeon.south_choice(choice, player)
            if location == "exit"
                trapped = false
            elsif location
                player_direction = location
            end

        elsif player_direction == "W"
            
            dungeon.print_west_direction

            print ": "
            choice = gets().strip().to_i()
            puts "\n" * 20
            
            location = dungeon.west_choice(choice, player)
            if location == "Game Over, your journey has come to an end!"
                puts location
                game_over = true
            elsif location
                player_direction = location
            end
        end
    end

    if game_over
        return false
    else 
        return true
    end
end

def roadblock1(player)
    
    puts "As you were making your way out of Central Park you have come to a roadblock.  It is the old pigeon Lady from the movie Home Alone, she is blocking your path and you need to get rid of the pidgeons somehow. Wouldn't bird seed be useful here?"

    continue = 0
    while continue != 1
        print "Press 1 to continue: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end

    if player.is_in_inventory?("Bird Seed")
        puts "Winner Winner, Pidgeon Dinner!! You have distracted the pidgeons away from the path with the bird seed and you can make your way to the airport!"
    else 
       
        random_number = rand(1..5)

        answer = 1
        while answer <= 1 || answer > 5
            puts "The old pidgeon lady has given you an ultimatum: Guess my number between 1 and 5 that is in my head. If you lose I will set my pidgeons on you!"
            print ": "
            answer = gets.strip.to_i()
        end

        if answer == random_number
            player.update_score(50)
            puts "The old pidgeon lady has had a change of heart and gives you a warm hug and sends you on your way with a bonus point increase of 50." + " Your total is now: #{player.score}".green
        else
            player.change_health(-25)
            puts "The pidgeons are set loose and peck you over and over. Looks like you got a case of the bird flu. Minus 25 hearts." + " Your health is now at: #{player.health} hearts.".red
        end
    end

    continue = 0
    while continue != 1
        print "Press 1 to continue: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end
end

def roadblock2(player)

    puts "\n" * 20
    puts" While making your way to the airport you have decided to make a quick pitstop via Brunswick East to grab yourself a quick coffee and while doing so you have been taken hostage by the elusive soy chai latte drinking, mid stomach high jeans wearing bearded hipster named Clive. Clive has challenged you to an eating competition and is adamant it involves his deconstructed Vegemite on toast"

    answered = false
    while !answered
        puts "Please enter between 1 and 20 how many pieces of Vegemite on toast you think you can eat: "
        print ": "
        answer = gets.strip.to_i()
        if answer < 8
            puts "Wow... really...thats all you could fit it in??"
            answered = true
        elsif answer > 8 && answer < 12
            player.update_score(100)
            puts "Good onya mate! You won the challenge and now Clive has to shave off his beard and sell out to the man." + " You win 100 points and your score is now #{player.score}".green
            answered = true
        elsif answer > 12 
            player.change_health(-25)
            puts "Congrats you win ya glutton, though now you have overdosed on vitamin B, you lose 25 hearts." + " Your current health is #{player.health}".green
            answered = true
        else 
            puts "This is an invalid input please try again".red
        end
    end

    continue = 0
    while continue != 1
        print "Press 1 to continue: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end
end

def roadblock3(player)
    puts "\n" * 20
    puts "While making your way to the final finish line you have run into Prince Harry and Meagan Markle, they have a got a quick quiz about your trip to give you a final chance to ensure your victory and accumulate some points and health!"
    puts "Your first question is:  What is New York’s nickname?"
    puts "
    1. The Big Easy
    2. The Big Apple
    3. The Big Banana
    "
    print ": "
    answer = gets.strip.to_i()
    puts "\n" * 20
    if answer == 2
        player.update_score(50)
        puts "Congratulations, what an awesome start to your quiz! You have won 50 points! Your total is now #{player.score}"
    else
        puts "No, you weren't paying attention were you?
    ".red
    end

    
    puts "Your second question is: What the name of the elusive soy chai latte drinking, waist high jeans wearing bearded hipster?"
    puts "
    1. Gerald
    2. Benito
    3. Clive
    "
    print ": "
    answer = gets.strip.to_i()
    puts "\n" * 20
    if answer == 3
        player.update_score(50)
        puts "Congratulations, yes, Clive is quite the hipster name isn't it!" + " You have won 50 points! Your total is now #{player.score}".green
    else
        puts "No, you weren't paying attention were you?
    ".red
    end

    puts "Your third and final question is: What is the name of the movie which the pigeon lady originates from? "
    puts "
    1. Top Gun
    2. Home Alone
    3. The Dark Knight
    "
    print ": "
    answer = gets.strip.to_i()
    puts "\n" * 20
    if answer == 2
        player.update_score(50)
        puts "Congratulations, on completing the quiz on a high note!" + " You have won 50 points! Your total is now #{player.score}".green
    else
        puts "No, you weren't paying attention were you?
    ".red
    end
end

def game_introduction()
    # returns a player object
    # introduces the game and scenario

    # INTRO GEM SCREEN
    puts "\n" * 20
    File.open("Big_city_skyline.rtf", "r") do |f|
        f.each_line do |line|
            puts line
        end
    end
    title = Artii::Base.new :font => 'slant'
    puts title.asciify('Big City Escapes!')

    continue = 0
    while continue != 1
        print "Press 1 to begin: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end

    puts "\n" * 20
    puts "Welcome to Big City Escapes! You are about to embark on a trip to 3 BIG cities! In each city you may get yourself stuck in some situations that you need to escape from.  Follow the prompts to get the best clues on how to escape from each dilemma you face, be careful along the way you may run into a few roadblocks.".yellow + " 

    You will be playing for the ultimate prize of $1 million dollars tax free cash plus a donation of".yellow + " about 3 fiddy ".green + "to a charity of your choice. ".yellow


    continue = 0
    while continue != 1
        print "Press 1 to continue: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end

    puts "Each player will start with a health of ".yellow + "100 Hearts.".red + " 
    Be sure to keep an eye on your health as you navigate your way through the challenges as your health may be affected at certain roadblocks through this trip.  
    Also for each challenge played you have the chance to win a certain amount of points. 
    The player who finishes the game with the most health and points will win the".yellow + " ultimate prize! ".green

    name = "place_holder"
    while name.length < 0 || name.length > 6
        print "Please enter your name: "
        name = gets.strip
        puts "\n" * 20
    end

    return Player.new(name)
end

def new_york_greeting

    puts "Welcome to the Big Apple or otherwise known as New York! 
    You have been greeted at the JFK international airport by Donald Trump and has slapped his trademark 'Make America Great Again' hat on you and set you on your way to Central Park for your first challenge. "

    continue = 0
    while continue != 1
        print "Press 1 to continue: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end

    puts "Arriving at Central Park, you have made it to the lake in the middle and decided to hire a boat to take in the sights of the Big Apple! As you are paddling out towards the centre of the lake, you drop your paddle and it splinters a hole through the bottom of the boat and has sprung a leak! You need to escape the lake as soon as possible before you sink. "

    continue = 0
    while continue != 1
        print "Press 1 to continue: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end
end

def melbourne_greeting

    puts "\n" * 20
    puts "Welcome to Melbourne! A bustling combination of sports, live music and coffee culture. 
    You have been greeted at the Melbourne International Airport by the outstanding and one of Australia’s most ‘reputable’ tennis players Nick Kyrgios. He will accompany you to Rod Laver Arena for your next challenge. …Just a tip don’t make him wait too long at the airport as his patience is extremely limited! "

    continue = 0
    while continue != 1
        print "Press 1 to continue: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end

    puts "You have now arrived at Rod Laver Arena and Nick wants to challenge you to a game of tennis. You swiftly beat him in the game of tennis and he is NOT happy.  You are both invited to the commentary box for the post match interview. By this stage Nick is fuming and has gone on one his famous rants which has gone for so long that you fall asleep. When you wake up everyone is gone and you are locked inside the commentary box. Look around and good luck on your escape!"

    continue = 0
    while continue != 1
        print "Press 1 to continue: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end
end

def london_greeting

    puts "Welcome to London! 
    London is home to most famous Royal Family in the world and historic landmarks such as Big Ben and Westminster Abbey. 
    You have been greeted at Heathrow Airport by the one and only Sherlock Holmes. He needs your help to solve a crime in East London as there is a serial killer on the loose. His assistant Watson is on annual leave and you need to help him out. "

    continue = 0
    while continue != 1
        print "Press 1 to continue: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end

    puts "You arrive in East London, its late at night and the two of you are walking along Brick Lane through the foggy London evening. Sherlock and yourself are starting to get the feeling that someone is following you. All of a sudden you are in a struggle with Jack The Ripper! Sherlock Holmes abandons you and runs off down the street like a noodled armed choir girl squealing and you end up knocked out and wake up in a pitch black dungeon room. You need to escape! "

    continue = 0
    while continue != 1
        print "Press 1 to continue: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end
end

def finish_line(player)
    
    puts "Phwoah! What an excellent adventure! Well done, you've made it to the finish line in one piece. Let's see if your final score was enough to clinch that ultimate prize of $1 million dollars! (and about a 3 fiddy donation to a charity of your choice). You will need to be at the top scoring range to bring home the dough."

    continue = 0
    while continue != 1
        print "Press 1 to view the highscore: "
        continue = gets.strip.to_i()
        puts "\n" * 20
    end

    # scoreboard
    set_scoreboard = [["Kevin", 750], ["Suki", 600], ["Jov", 550], ["Jordan", 400], ["Clinton", 50]]

    player_score_block = [player.name, player.score]

    inserted = false
    count = 0
    while count < set_scoreboard.length && !inserted
        if player.score > set_scoreboard[count][1]
            set_scoreboard.insert(count, player_score_block) 
            inserted = true
        end
        count += 1
    end

    if !inserted 
        set_scoreboard << player_score_block
    end
    
    puts set_scoreboard
    if set_scoreboard[0] == player_score_block
        puts "Woohoo! You are the champion! You have won $1 million dollars + a donation of about 3 fiddy to a charity of your choice! Thank you for playing Big City Escapes!"
    else
        puts "Unlucky! You missed that top spot, we will still however give you about a 3 fiddy donation to a charity of your choice! Thank you for playing Big City Escapes!"
    end
end

def finish_line_test
    barry = Player.new("Barry")
    barry.update_score(500)

    # Expect Barry to sit on the scoreboard between Jov and Jordan
    finish_line(barry)
end

def player_is_in_inventory_test()

    player = Player.new("Player")
    player.add_item("Dog")

   
    if player.is_in_inventory?("Dog")
        puts "player_is_in_inventory_test ran as expected"
    else
        puts "player_is_in_inventory_test did not run as expected"
    end

    if player.is_in_inventory?("Cat")
        puts "player_is_in_inventory_test did not run as expected"
    else
        puts "player_is_in_inventory_test ran as expected"
    end
end

def player_change_health_test()
    
    # Initial health = 100
    player = Player.new("Player")

    player.change_health(-25)
    if player.health == 75
        puts "player_change_health_test ran as expected"
    else
        puts "player_change_health_test did not run as expected"
    end

    player.change_health(-25)
    player.change_health(-25)
    if player.change_health(-25) == "Game Over, your journey has come to an end!"
        puts "player_change_health_test ran as expected"
    else
        puts "player_change_health_test did not run as expected"
    end

end

def main()
    # Main function

    # introduction
    player = game_introduction()

    dead = false
    # New York
    new_york_greeting
    continue = boat_escape(player)
    if !continue
        dead = true
    end
        
    if !dead
        roadblock1(player)
    end


    # Melbourne
    
    if !dead
        melbourne_greeting
        continue = aus_open_escape(player)
    end
    if !continue
        dead = true
    end

    if !dead
        roadblock2(player)
    end


    # London
    
    if !dead
        london_greeting
        continue = london_dungeon(player)
    end
    if !continue
        dead = true
    end

    if !dead
        roadblock3(player)
    end

    # Outro
    if !dead
        finish_line(player)
        end_message = Artii::Base.new :font => 'slant'
        puts end_message.asciify('You made it!')
    end

    if dead
        File.open("Big_city_skull.rtf", "r") do |f|
            f.each_line do |line|
                puts line
            end
        end
        end_message = Artii::Base.new :font => 'slant'
        puts end_message.asciify('Game Over')
    end
end

main